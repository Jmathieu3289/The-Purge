export class DBResponse {
    public data: any = null;
    public errors: Array<string> = [];
}
