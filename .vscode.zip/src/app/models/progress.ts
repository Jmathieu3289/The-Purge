export class Progress {
    public id: number;
    public category: string;
    public current_count: number;
    public max_count: number;
    public credits: number;
}
