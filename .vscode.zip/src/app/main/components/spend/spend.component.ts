import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spend',
  templateUrl: './spend.component.html',
  styleUrls: ['./spend.component.css']
})
export class SpendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
